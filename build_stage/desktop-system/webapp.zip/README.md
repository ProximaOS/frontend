# OpenOrchid
## System
System is a crucial part for OpenOrchid's Ui to function.
It's the thing that contains your navbar, statusbar, browser, gestures, and app windows.
