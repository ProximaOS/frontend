!(function (exports) {

'use strict';

document.addEventListener('DOMContentLoaded', function () {
  Splashscreen.hide();
});

})(window);
