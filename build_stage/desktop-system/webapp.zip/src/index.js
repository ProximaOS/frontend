!(function (exports) {

'use strict';

import '../scss/context_menu.scss';

})(window);
