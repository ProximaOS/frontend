!(function (exports) {
  'use strict';

  const DataIcon = {
    iconElement: document.getElementById('statusbar-cellular-signal'),

    init: function () {
      this.update();
    },

    update: function () {
      this.iconElement.classList.remove('hidden');

      clearTimeout(this.timer);
      this.timer = setTimeout(this.update, 1000);
    }
  };

  DataIcon.init();
})(window);
