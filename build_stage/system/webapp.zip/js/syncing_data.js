!(function (exports) {
  'use strict';

  const SyncingData = {
    init: function () {}
  };

  SyncingData.init();
})(window);
