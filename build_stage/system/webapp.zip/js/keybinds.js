!(function (exports) {
  'use strict';

  const Keybinds = {
    init: function () {}
  };

  Keybinds.init();
})(window);
