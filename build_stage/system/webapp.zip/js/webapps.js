!(function (exports) {
  'use strict';

  const Webapps = {
    init: function () {}
  };

  Webapps.init();
})(window);
