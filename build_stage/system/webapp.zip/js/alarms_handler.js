!(function (exports) {
  'use strict';

  const AlarmsHandler = {
    init: function () {}
  };

  AlarmsHandler.init();
})(window);
