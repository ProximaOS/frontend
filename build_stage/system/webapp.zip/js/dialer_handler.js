!(function (exports) {
  'use strict';

  const DialerHandler = {
    init: function () {}
  };

  DialerHandler.init();
})(window);
